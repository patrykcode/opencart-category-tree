<?php

if (php_sapi_name() == 'cli') {
    // include_once '../../config.php';
}

class db
{
    public $connection = null;
    public $query = null;
    public static $instance = null;

    public static $PRODUCT_TABLE = 'INSERT INTO `oc_product` (`model`,`sku`, `upc`,`ean`,`jan`,`isbn`,`mpn`,`location`, `quantity`,`flag`,`stock_status_id`,`image`,`shipping`,`price`,`points`,`manufacturer_id`,`date_available`,`weight`,`weight_class_id`,`length`,`width`,`height`, `length_class_id`,`subtract`,`minimum`,`tax_class_id`,`sort_order`,`status`,`_import`,`_import_type`,`date_added`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)';
    public static $PRODUCT_SELECT = 'SELECT product_id FROM `oc_product` WHERE `model` IN (?,?);';
    public static $UPDATE_PRODUCT_TABLE = 'UPDATE `oc_product` SET `price`=?,`model`=?,`image`=?, `_import_type`=? ,`status`=? ,`date_modified`=? WHERE `product_id`=?;';
    public static $UPDATE_DESC_TABLE = 'UPDATE `oc_product_description` SET `description`=?,`_import_type`=? WHERE `product_id`=?;';
    public static $PRODUCT_DESC_TABLE = 'INSERT INTO `oc_product_description`(`product_id`, `language_id`, `name`, `description`, `tag`, `meta_title`, `meta_description`, `meta_keyword`, `_import`, `_import_type`) VALUES (?,?,?,?,?,?,?,?,?,?)';
    public static $PRODUCT_TO_STORE = 'INSERT INTO `oc_product_to_store`(`product_id`, `store_id`, `_import`, `_import_type`) VALUES (?,?,?,?)';
    public static $PRODUCT_TO_CATEGORY = 'INSERT INTO `oc_product_to_category`(`product_id`, `category_id`, `_import`, `_import_type`) VALUES (?,?,?,?)';
    public static $PRODUCT_IMAGE = 'INSERT INTO `oc_product_image`(`product_id`, `image`, `sort_order`, `_import`, `_import_type`) VALUES (?,?,?,?,?)';
    public static $CATEGORY = 'INSERT INTO `oc_category`(`parent_id`,`_import_type`, `top`, `column`, `sort_order`, `status`,`date_modified`,`date_added`) VALUES (?,?,0,1,0,1,NOW(),NOW())';
    public static $CATEGORY_TO_STORE = 'INSERT INTO `oc_category_to_store`(`category_id`, `store_id`, `_import`, `_import_type`) VALUES (?,0,0,?)';
    public static $CATEGORY_DESCTIPTION = 'INSERT INTO `oc_category_description`(`category_id`, `language_id`, `name`, `description`, `meta_title`, `meta_description`, `meta_keyword`, `_import`, `_import_type`) VALUES (?,?,?,?,?,?,?,?,?)';
    public static $CATEGORY_PATH = 'INSERT INTO `oc_category_path`(`category_id`, `path_id`, `level`, `_import`, `_import_type`) VALUES (?,?,?,0,?)';
    public static $CATEGORY_FOC = 'SELECT * FROM `oc_category_description` cd LEFT JOIN `oc_category` c on c.category_id=cd.category_id WHERE cd.`_import_type` =? AND c.parent_id =? AND cd.name =?';

    public function __construct($data = [])
    {
        $username = isset($data['DB_USERNAME']) ? $data['DB_USERNAME'] : DB_USERNAME;
        $password = isset($data['DB_PASSWORD']) ? $data['DB_PASSWORD'] : DB_PASSWORD;
        $host = isset($data['DB_HOSTNAME']) ? $data['DB_HOSTNAME'] : DB_HOSTNAME;
        $db = isset($data['DB_DATABASE']) ? $data['DB_DATABASE'] : DB_DATABASE;
        try {
            if ($this->connection == null) {
                $options = array(
                    \PDO::MYSQL_ATTR_FOUND_ROWS => true,
                    \PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION,
                    \PDO::ATTR_EMULATE_PREPARES => false,
                );

                $this->connection = new \PDO("mysql:dbname=$db;host=$host", $username, $password, $options);

                $this->connection->exec('set names utf8');
            }
        
            return $this;
        } catch (\PDOException $e) {
            exit('Error: '.$e->getMessage()."\n");
        }
        return $this;
    }

    public static function gi($data)
    {
        $db = isset($data['DB_DATABASE']) ? $data['DB_DATABASE'] : DB_DATABASE;
        if (!isset(self::$instance[$db])) {
            self::$instance[$db] = new db($data);
        }

        return self::$instance[$db];
    }

    public function getLastid()
    {
        return $this->connection->lastInsertId();
    }

    public function beginTransaction()
    {
        $this->connection->beginTransaction();
    }

    public function rollBack()
    {
        $this->connection->rollBack();
    }

    public function commit()
    {
        $this->connection->commit();
    }

    public function query($sql, $values = [])
    {
        try {
            $this->query = $this->connection->prepare($sql);
            if (is_array($values)) {
                $this->query->execute(array_values($values));
            } else {
                $this->query->execute();
            }

            return $this;
        } catch (PDOException $e) {
            echo $sql;
            echo 'Error: '.$e->getMessage();
            var_dump($sql, $values);
        }

        return false;
    }

    public function select($sql, $where = [])
    {
        $this->query = $this->connection->prepare($sql);
        $this->query->execute(array_values($where));

        return $this;
    }

    public function first($column = '*')
    {
        $all = $this->query->fetch(PDO::FETCH_ASSOC);

        if (is_array($column) || ($column != '*' && is_string($column))) {
            if (is_string($column)) {
                $column = explode(',', $column);
            }
            if (is_array($all)) {
                return array_filter($all, function ($key) use ($column) {
                    return in_array($key, $column);
                }, ARRAY_FILTER_USE_KEY);
            }
        }

        return $all;
    }

    public function get()
    {
        return $this->query->fetchall(PDO::FETCH_ASSOC);
    }

    public function count()
    {
        return $this->query->rowCount();
    }
}

function db($data = [])
{
    return db::gi($data);
}
function dd()
{
    var_dump(func_get_args());
    exit;
}